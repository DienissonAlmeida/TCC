﻿using eFlight.Application.Features.TravelPackages.Commands;
using eFlight.Domain.Features.TravelPackages;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace eFlight.Application.Features.TravelPackages.Handlers
{
    public class TravelPackageReservationCreateHandler : IRequestHandler<TravelPackageReservationRegisterCommand, bool>
    {
        private readonly ITravelPackageReservationRepository _travelPackageReservationRepository;

        public TravelPackageReservationCreateHandler(ITravelPackageReservationRepository repository)
        {
            _travelPackageReservationRepository = repository;
        }

        public async Task<bool> Handle(TravelPackageReservationRegisterCommand request, CancellationToken cancellationToken)
        {
            return true;
        }
    }
}
