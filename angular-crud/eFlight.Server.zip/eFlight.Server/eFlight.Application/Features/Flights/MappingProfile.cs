﻿using AutoMapper;
using eFlight.Application.Features.Flights.Commands;
using eFlight.Domain.Features.Flights;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Application.Features.Flights
{
    public class MappingProfile : Profile
    {
        public MappingProfile()
        {
            CreateMap<FlightReservationRegisterCommand, Flight>();
            CreateMap<FlightReservationUpdateCommand, Flight>();
            CreateMap<CustomerUpdateCommand, Customer>();
        }
    }
}
