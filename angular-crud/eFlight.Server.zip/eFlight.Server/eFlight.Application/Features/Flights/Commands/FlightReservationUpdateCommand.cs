﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Application.Features.Flights.Commands
{
    public class FlightReservationUpdateCommand : IRequest<bool>
    {
        public int Id { get; set; }

        public DateTime Date { get; set; }

        public DateTime Return { get; set; }

        public virtual IList<CustomerUpdateCommand> Customers { get; set; }

    }
}
