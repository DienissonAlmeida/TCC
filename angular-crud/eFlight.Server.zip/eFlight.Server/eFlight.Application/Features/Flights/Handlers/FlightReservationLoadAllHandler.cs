﻿using eFlight.Application.Features.Flights.Queries;
using eFlight.Domain.Features.Flights;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace eFlight.Application.Features.Flights.Handlers
{
    public class FlightReservationLoadAllHandler : IRequestHandler<FlightReservationLoadAllQuery, List<FlightReservation>>
    {
        private readonly IFlightReservationRepository _repository;
        public FlightReservationLoadAllHandler(IFlightReservationRepository flightRepository)
        {
            _repository = flightRepository;
        }


        public Task<List<FlightReservation>> Handle(FlightReservationLoadAllQuery request, CancellationToken cancellationToken)
        {
            return _repository.GetAll();
        }
    }
}
