﻿using eFlight.Application.Features.Flights.Commands;
using eFlight.Domain.Features.Flights;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace eFlight.Application.Features.Flights.Handlers
{
    public class FlightReservationCreateHandler : IRequestHandler<FlightReservationRegisterCommand, bool>
    {
        private readonly IFlightReservationRepository _flightReservationRepository;

        public FlightReservationCreateHandler(IFlightReservationRepository repository)
        {
            _flightReservationRepository = repository;
        }

        //public async Task<Unit> Handle(FlightReservationRegisterCommand request, CancellationToken cancellationToken)
        //{
        //    try
        //    {
        //        var resultDb = await _flightReservationRepository.GetAllIncludeCustomers();

        //        resultDb.ForEach(flightDb => flightDb.Customers.ToList()
        //        .ForEach(customer => FlightReservation._reservedSeats.Add(new Seat() { Number = customer.Id })));

        //        var flight = new FlightReservation()
        //        {

        //        };

        //        foreach (var passenger in request.PassengerRegisterCommand)
        //        {
        //            flight.Passengers.Add(new Passenger()
        //            {
        //                Name = passenger.Name,
        //                LastName = passenger.LastName,
        //                Sex = passenger.Sex
        //            });
        //        }

        //        flight.CanRegister();

        //        var result = await _flightReservationRepository.Add(flight);

        //        return await Task.FromResult(new Unit());

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        public async Task<bool> Handle(FlightReservationRegisterCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var flightReservation = new FlightReservation()
                {
                    FlightId = request.FlightId,
                    InputDate = request.Date,
                    OutputDate = request.Return,
                    Customers = new List<Customer>()
                };

                foreach (var customer in request.CustomerRegisterCommand)
                {
                    flightReservation.Customers.Add(new Customer()
                    {
                        Name = customer.Name,
                        LastName = customer.LastName,
                        Sex = customer.Sex
                    });
                }

                flightReservation.CanRegister();

               await _flightReservationRepository.Add(flightReservation);

                var resultDb = await _flightReservationRepository.GetAllIncludeCustomers();

                resultDb.ForEach(flightDb => flightDb.Customers.ToList()
                        .ForEach(customer => FlightReservation._reservedSeats.Add(new Seat() { Number = customer.Id })));

                return true;
            }
            catch (InvalidOperationException ex)
            {
                return false;
            }
        }
    }
}
