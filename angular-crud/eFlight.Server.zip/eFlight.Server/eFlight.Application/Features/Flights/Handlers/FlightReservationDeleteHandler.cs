﻿using eFlight.Application.Features.Flights.Commands;
using eFlight.Domain.Features.Flights;
using MediatR;
using System;
using System.Threading;
using System.Threading.Tasks;

namespace eFlight.Application.Features.Flights.Handlers
{
    public class FlightReservationDeleteHandler : IRequestHandler<FlightReservationDeleteCommand, bool>
    {
        private readonly IFlightReservationRepository _flightRepository;

        public FlightReservationDeleteHandler(IFlightReservationRepository flightRepository)
        {
            _flightRepository = flightRepository;
        }

        public async Task<bool> Handle(FlightReservationDeleteCommand request, CancellationToken cancellationToken)
        {
            var flight = await _flightRepository.GetById(request.FlightReservationId);

            if (flight == null)
                return false;

            if (flight.CanDelete())
            {
                _flightRepository.DeleteById(flight.Id);
                return true;
            }
            else
            {
                return false;
            }

        }

    }
}
