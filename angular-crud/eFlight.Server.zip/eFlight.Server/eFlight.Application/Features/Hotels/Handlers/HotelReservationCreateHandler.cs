﻿using eFlight.Application.Features.Hotels.Commands;
using eFlight.Domain.Features.Hotels;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace eFlight.Application.Features.Hotels.Handlers
{
    public class HotelReservationCreateHandler : IRequestHandler<HotelReservationRegisterCommand, bool>
    {
        private readonly IHotelReservationRepository _hotelReservationRepository;

        public HotelReservationCreateHandler(IHotelReservationRepository repository)
        {
            _hotelReservationRepository = repository;
        }

        public async Task<bool> Handle(HotelReservationRegisterCommand request, CancellationToken cancellationToken)
        {
            return true;
        }
    }
}
