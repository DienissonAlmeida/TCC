﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Application.Features.Hotels.Commands
{
    public class HotelReservationRegisterCommand : IRequest<bool>
    {
    }
}
