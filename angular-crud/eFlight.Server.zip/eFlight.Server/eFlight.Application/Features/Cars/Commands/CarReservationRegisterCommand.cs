﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Application.Features.Cars.Commands
{
    public class CarReservationRegisterCommand : IRequest<bool>
    {
    }
}
