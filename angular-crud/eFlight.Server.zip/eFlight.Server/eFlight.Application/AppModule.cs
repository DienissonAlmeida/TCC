﻿using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Application
{
    public class AppModule
    {
    }
}
