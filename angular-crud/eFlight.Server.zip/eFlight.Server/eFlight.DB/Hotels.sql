﻿CREATE TABLE [dbo].[Hotels]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [City] VARCHAR(50) NULL, 
    [Name] VARCHAR(50) NULL, 
    [Stars] INT NULL
)
