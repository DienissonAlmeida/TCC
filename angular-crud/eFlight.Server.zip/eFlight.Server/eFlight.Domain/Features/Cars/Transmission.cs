﻿namespace eFlight.Domain.Features.Cars
{
    public enum Transmission
    {
        Manual,
        Automatic
    }
}