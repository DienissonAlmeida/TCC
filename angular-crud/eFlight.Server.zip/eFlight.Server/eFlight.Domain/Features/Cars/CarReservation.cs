﻿using eFlight.Domain.Features.Flights;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Domain.Features.Cars
{
    public class CarReservation : Reservation
    {
        public string Name { get; set; }

        public Car Car { get; set; }

        public int CarId { get; set; }

        public List<Customer> Customers { get; set; }
    }
}
