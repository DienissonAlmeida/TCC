﻿namespace eFlight.Domain.Features.Hotels
{
    public interface IHotelReservationRepository : IRepositoryBase<HotelReservation>
    {
    }
}
