﻿using eFlight.Domain.Features.Flights;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Domain.Features.Hotels
{
    public class HotelReservation : Reservation
    {
        public string Description { get; set; }
        public List<Customer> Customers { get; set; }
        public Hotel Hotel { get; set; }
        public int HotelId { get; set; }

    }
}
