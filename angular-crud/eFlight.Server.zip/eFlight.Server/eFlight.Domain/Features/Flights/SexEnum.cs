﻿namespace eFlight.Domain.Features.Flights
{
    public enum SexEnum
    {
        Male,
        Female
    }
}