﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace eFlight.Domain.Features.Flights
{
    public class FlightReservation : Reservation
    {
        //public static int Total;

        //Lugares Já Reservados
        public static IList<Seat> _reservedSeats = new List<Seat>();
        public IList<Customer> Customers { get; set; }
        public Flight Flight { get; set; }
        public int FlightId { get; set; }

        public void CanRegister()
        {

            if (_reservedSeats.Count >= 40)
                throw new InvalidOperationException("Voo lotado");

            foreach (var customer in Customers)
            {
                if (_reservedSeats.Any(x => x.Number == customer.Id))
                    throw new InvalidOperationException($"Assento já cadastrado: {customer.Id}");
            }

            foreach (var customer in Customers)
            {
                _reservedSeats.Add(new Seat() { Number = customer.Id });
            }


        }

        public bool CanDelete()
        {
            TimeSpan difference = InputDate - DateTime.Now;
            double days = difference.TotalDays;

            return days <= 10 ? false : true;
        }
    }
}
