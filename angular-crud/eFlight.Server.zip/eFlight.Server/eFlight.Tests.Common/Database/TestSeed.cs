﻿using eFlight.Data.Context;
using eFlight.Domain.Features.Flights;
using eFlight.Domain.Features.Hotels;
using eFlight.Tests.Common.Features.Flights;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Tests.Common.Database
{
    public class TestSeed
    {

        public FlightReservation FlightSeedOne { get; private set; }
        public FlightReservation FlightSeedTwo { get; private set; }
        public HotelReservation SiteSeed { get; private set; }

        private eFlightDbContext _context;

        public TestSeed(eFlightDbContext context)
        {
            _context = context;
        }

        public void RunSeed()
        {
            //Apagando e recriando o banco de dados
            _context.Database.EnsureDeleted();
            _context.Database.EnsureCreated();

            //Criação dos objetos
            FlightSeedOne = FlightReservationBuilder.Start().Build();
            FlightSeedOne.SetId();

            foreach (var customer in FlightSeedOne.Customers)
            {
                customer.SetId();
            }

            FlightSeedTwo = FlightReservationBuilder.Start().Build();
            FlightSeedTwo.SetId();

            foreach (var customer in FlightSeedOne.Customers)
            {
                customer.SetId();
            }

            //CustomerSeed = ObjectMother.GetNewValidCustomer(ObjectMother.GetNewValidAddress(), new List<Site>() { SiteSeed });
            //CustomerSeed.SetKey();
            //CustomerSeed.SetCreationDate();

            //Salvando os objetos e atribuindo as instâncias as variáveis do seed
            FlightSeedOne = _context.FlightReservation.Add(FlightSeedOne).Entity;
            FlightSeedTwo = _context.FlightReservation.Add(FlightSeedTwo).Entity;

            //Confirmando alterações
            _context.SaveChanges();
        }

    }
}
