﻿using eFlight.Domain.Features.Cars;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Tests.Common.Features.Cars
{
    public class CarReservationBuilder
    {
        private static CarReservation _carReservation;

        public static CarReservationBuilder Start()
        {
            _carReservation = new CarReservation()
            {

            };

            return new CarReservationBuilder();
        }

        public CarReservation Build() => _carReservation;
    }
}
