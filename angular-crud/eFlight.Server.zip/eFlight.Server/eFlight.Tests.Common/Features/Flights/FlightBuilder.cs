﻿using eFlight.Domain.Features.Flights;
using System;
using System.Collections.Generic;

namespace eFlight.Tests.Common.Features.Flights
{
    public class FlightBuilder
    {
        private static Flight _flight;

        public static FlightBuilder Start()
        {
            _flight = new Flight()
            {
                Origin = "Lages",
                Destination = "Campinas"
            };

            return new FlightBuilder();
        }

        public Flight Build()
        {
            return _flight;
        }

    }
}
