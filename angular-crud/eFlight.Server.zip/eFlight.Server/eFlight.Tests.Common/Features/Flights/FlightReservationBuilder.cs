﻿using eFlight.Domain.Features.Flights;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Tests.Common.Features.Flights
{
    public class FlightReservationBuilder
    {
        private static FlightReservation _reservation;

        public static FlightReservationBuilder Start()
        {
            _reservation = new FlightReservation()
            {
                Id = 1,
                InputDate = DateTime.Now,
                OutputDate = DateTime.Now.AddDays(10),
                //Flight = FlightBuilder.Start().Build(),
                Customers = new List<Customer>()
                {
                    CustomerBuilder.Start().Build()
                },
            };

            return new FlightReservationBuilder();
        }

        public FlightReservation Build() => _reservation;

        public FlightReservationBuilder WithFlightId(int flightId)
        {
            _reservation.FlightId = flightId;
            return this;
        }

        public FlightReservationBuilder WithInputDate(DateTime date)
        {
            _reservation.InputDate = date;
            return this;
        }

        public FlightReservationBuilder WithOutputDate(DateTime date)
        {
            _reservation.OutputDate = date;
            return this;
        }

        public FlightReservationBuilder WithSeats(List<Seat> seats)
        {
            FlightReservation._reservedSeats = seats;
            return this;
        }

        public FlightReservationBuilder WithCustomers(List<Customer> customers)
        {
            _reservation.Customers = customers;
            return this;
        }

    }
}
