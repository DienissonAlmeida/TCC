﻿using eFlight.Application.Features.Flights.Commands;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Tests.Common.Features.Flights
{
    public class FlightReservationUpdateCommandBuilder
    {
        private static FlightReservationUpdateCommand _command;

        public static FlightReservationUpdateCommandBuilder Start()
        {
            _command = new FlightReservationUpdateCommand()
            {
                Id = 1,
                Date = DateTime.Now,
                Return = DateTime.Now.AddDays(10),
                Customers = new List<CustomerUpdateCommand>()
                {
                    PassengerUpdateCommandBuilder.Start().Build()
                }
            };

            return new FlightReservationUpdateCommandBuilder();
        }

        public FlightReservationUpdateCommand Build() => _command;

        public FlightReservationUpdateCommandBuilder WithId(int id)
        {
            _command.Id = id;
            return this;
        }
    }
}
