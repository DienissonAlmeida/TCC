﻿using eFlight.Domain.Features.Hotels;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Tests.Common.Features.Hotels
{
    public class HotelReservationBuilder
    {
        private static HotelReservation _travelPackage;

        public static HotelReservationBuilder Start()
        {
            _travelPackage = new HotelReservation()
            {

            };

            return new HotelReservationBuilder();
        }

        public HotelReservation Build() => _travelPackage;
    }
}
