﻿using eFlight.Application.Features.Hotels.Commands;

namespace eFlight.Tests.Common.Features.Hotels
{
    public class HotelReservationRegisterCommandBuilder
    {
        private static HotelReservationRegisterCommand _command;

        public static HotelReservationRegisterCommandBuilder Start()
        {
            _command = new HotelReservationRegisterCommand()
            {


            };

            return new HotelReservationRegisterCommandBuilder();
        }

        public HotelReservationRegisterCommand Build() => _command;
    }
}
