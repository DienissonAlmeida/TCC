﻿using eFlight.Application.Features.TravelPackages.Commands;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Tests.Common.Features.TravelPackages
{
    public class TravelPackageReservationRegisterCommandBuilder
    {
        private static TravelPackageReservationRegisterCommand _command;

        public static TravelPackageReservationRegisterCommandBuilder Start()
        {
            _command = new TravelPackageReservationRegisterCommand()
            {


            };

            return new TravelPackageReservationRegisterCommandBuilder();
        }

        public TravelPackageReservationRegisterCommand Build() => _command;
    }
}
