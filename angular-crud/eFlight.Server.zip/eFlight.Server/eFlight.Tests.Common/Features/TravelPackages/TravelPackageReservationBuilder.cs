﻿using eFlight.Domain.Features.TravelPackages;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Tests.Common.Features.TravelPackages
{
    public class TravelPackageReservationBuilder
    {
        private static TravelPackageReservation _travelPackage;

        public static TravelPackageReservationBuilder Start()
        {
            _travelPackage = new TravelPackageReservation()
            {

            };

            return new TravelPackageReservationBuilder();
        }

        public TravelPackageReservation Build() => _travelPackage;
    }
}
