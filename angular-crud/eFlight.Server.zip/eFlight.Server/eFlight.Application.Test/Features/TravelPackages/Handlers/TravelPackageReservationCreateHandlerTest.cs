﻿using eFlight.Application.Features.TravelPackages.Handlers;
using eFlight.Domain.Features.TravelPackages;
using eFlight.Tests.Common.Features.TravelPackages;
using FluentAssertions;
using Moq;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using Xunit;

namespace eFlight.Application.Test.Features.TravelPackages.Handlers
{
    public class TravelPackageReservationCreateHandlerTest : IClassFixture<BaseTest>
    {
        private TravelPackageReservationCreateHandler _handler;
        private Mock<ITravelPackageReservationRepository> _fakeRepository;

        public TravelPackageReservationCreateHandlerTest()
        {
            _fakeRepository = new Mock<ITravelPackageReservationRepository>();
            _handler = new TravelPackageReservationCreateHandler(_fakeRepository.Object);
        }

        [Fact]
        public async Task Deveria_criar_reserva_de_pacote_de_viagem_com_sucesso()
        {
            int expected = 1;
            List<TravelPackageReservation> reservations = new List<TravelPackageReservation>()
            {
                TravelPackageReservationBuilder.Start().Build(),
            };

            //_fakeRepository.Setup(x => x.GetAllIncludeCustomers()).ReturnsAsync(reservations);

            var cmd = TravelPackageReservationRegisterCommandBuilder.Start().Build();

            var result = await _handler.Handle(cmd, It.IsAny<CancellationToken>());

            result.Should().BeTrue();
            //_fakeRepository.Verify(x => x.GetAllIncludeCustomers(), Times.Once);
            //_fakeRepository.Verify(x => x.Add(It.IsAny<TravelPackageReservation>()), Times.Once);
            //FlightReservation.Total.Should().Be(1);
            //FlightReservation._reservedSeats.Should().HaveCount(2);

        }
    }
}