using eFlight.Data.Context;
using eFlight.Tests.Common.Database;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using Xunit;

namespace eFlight.Infra.Data.Tests.Base
{
    public class TestBase
    {
        protected eFlightDbContext Context { get; private set; }
        protected TestSeed Seeder { get; set; }

        private IConfigurationRoot _appSettings;
        private string _connectionString;

        public TestBase()
        {
            _appSettings = new ConfigurationBuilder()
                .AddJsonFile("appsettings.json")
                .Build();

            _connectionString = _appSettings.GetValue<string>("AppSettings:ConnectionString");

            var options = new DbContextOptionsBuilder<eFlightDbContext>()
            .UseInMemoryDatabase(_connectionString)
            .Options;

            Context = new eFlightDbContext(options);

            Seeder = new TestSeed(Context);
            Seeder.RunSeed();
        }

    }
}
