﻿using eFlight.Infra.Data.Tests.Base;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Infra.Data.Tests.TravelPackages
{
    public class TravelPackageRepositoryTest : TestBase
    {
        private FlightReservationRepository _repository;

        public FlightReservationRepositoryTest()
        {
            _repository = new FlightReservationRepository(Context);
        }

        [Fact]
        public async Task Deveria_adicioanar_um_voo_no_contexto()
        {
            //Arrange
            FlightReservation flightReservation = FlightReservationBuilder.Start().Build();

            //Customer newCustomer = ObjectMother.GetNewValidCustomer(ObjectMother.GetNewValidAddress(), new List<Site>() { site });
            flightReservation.SetId();

            foreach (var customer in flightReservation.Customers)
            {
                customer.SetId();
            }
            //newCustomer.SetCreationDate();

            //Action
            var flightReservationAdd = await _repository.Add(flightReservation);

            //Assert
            //flightAdd.IsSuccess.Should().BeTrue();
            //flightAdd.Success.Should().NotBeNull();
            //flightAdd.Success.Id.Should().BeGreaterThan(0);
            var expectedFlight = Context.FlightReservation.Find(flightReservationAdd.Id);
            expectedFlight.Should().NotBeNull();
        }

        #region GET

        [Fact]
        public void Deveria_retornar_todos_as_reservas_de_voos_do_contexto()
        {
            //Action
            var flightsReservation = _repository.GetAll().Result.ToList();

            //Assert
            flightsReservation.Should().HaveCount(2);
        }

        //TODO: Analisar uma forma de retornar somente a entidade e não as dependencias
        [Fact]
        public async Task Deveria_retornar_o_voo_pelo_id()
        {
            //Action
            var flightReservationDb = await _repository.GetById(Seeder.FlightSeedOne.Id);

            //Assert
            flightReservationDb.Id.Should().Equals(Seeder.FlightSeedOne.Id);

        }

        [Fact]
        public void Deveria_retornar_os_voos_e_as_dependencias()
        {
            //Action
            var flights = _repository.GetAllIncludeCustomers();

            //Assert            flights.Result.Should().HaveCount(2);
            flights.Result.ForEach(c =>
            {
                c.Customers.Should().HaveCount(1);
            });
        }

        [Fact]
        public async Task Deveria_retornar_voo_por_id_e_suas_dependencias()
        {
            //Action
            var flightDb = await _repository.GetById(Seeder.FlightSeedOne.Id);

            //Assert
            flightDb.Id.Should().Equals(Seeder.FlightSeedOne.Id);
            flightDb.Customers.Should().NotBeNull();
        }
        #endregion GET

        [Fact]
        public async Task Deveria_excluir_reserva_de_voo_do_contexto()
        {
            //Action
            var callbackRemove = _repository.DeleteById(Seeder.FlightSeedOne.Id);

            //Assert

            var flights = _repository.GetAll();

            flights.Result.Should().HaveCount(1);
        }

        [Fact]
        public async Task Deveria_atualizar_reserva_de_voo_no_contexto()
        {
            //Arrange

            foreach (var customer in Seeder.FlightSeedOne.Customers)
            {
                customer.Name = "Teste Update";
            }

            //Action
            await _repository.Update(Seeder.FlightSeedOne);

            //Assert
            var expectedFlight = Context.FlightReservation.Find(Seeder.FlightSeedOne.Id);
            expectedFlight.Customers.Should().HaveCount(1);
        }
    }
}
