using System;
using Xunit;
using eFlight.Domain.Features.Flights;
using System.Collections.Generic;
using FluentAssertions;
using eFlight.Tests.Common.Features.Flights;
using eFlight.Tests.Common.Features;

namespace eFlight.Domain.Test
{
    public class FlightTest
    {
        public FlightTest()
        {
            FlightReservation._reservedSeats = new List<Seat>();
        }

        [Fact]
        public void Deveria_cadastrar_reserva_com_dois_assentos()
        {
            var customer = CustomerBuilder.Start().Build();

            var flightReservation = FlightReservationBuilder.Start().WithCustomers(new List<Customer>() { customer }).Build();

            flightReservation.CanRegister();

            FlightReservation._reservedSeats.Should().HaveCount(1);
        }

        [Theory]
        [InlineData(1, 2)]
        public void Nao_deveria_cadastrar_reserva_com_assento_ja_cadastrado(int value1, int value2)
        {
            var customer = CustomerBuilder.Start().WithId(value1).Build();
            var customeTwo = CustomerBuilder.Start().WithId(value2).Build();

            var flightReservationTwo = FlightReservationBuilder.Start().WithCustomers(new List<Customer>() { customer, customeTwo }).Build();

            FlightReservation._reservedSeats = Populate(new int[] { 1, 3, 5, 7, 9 });

            Action act = () => flightReservationTwo.CanRegister();
            act.Should().Throw<InvalidOperationException>().WithMessage("Assento j� cadastrado: 1");
            FlightReservation._reservedSeats.Should().HaveCount(5);
        }

        [Fact]
        public void Nao_deveria_cadastrar_reserva_quando_lotado()
        {
            var flightReservation = FlightReservationBuilder.Start().Build();

            FlightReservation._reservedSeats = 
                Populate(new int[] { 1, 2, 3, 4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38,39,40 });


            Action act = () => flightReservation.CanRegister();
            act.Should().Throw<InvalidOperationException>().WithMessage("Voo lotado");
            FlightReservation._reservedSeats.Should().HaveCount(40);
        }

        [Fact]
        public void Nao_deveria_excluir_reserva_de_voo_com_menos_de_10_dias()
        {
            var flightReservation = FlightReservationBuilder.Start().WithInputDate(DateTime.Now.AddDays(9)).Build();

            flightReservation.CanDelete().Should().BeFalse();
        }
        [Fact]
        public void Deveria_excluir_reserva_de_voo_com_mais_de_10_dias()
        {
            var flightReservation = FlightReservationBuilder.Start().WithInputDate(DateTime.Now.AddDays(12)).Build();

            flightReservation.CanDelete().Should().BeTrue();
        }

        private List<Seat> Populate(int[] count)
        {
            var list = new List<Seat>();

            for (int i = 0; i < count.Length; i++)
            {
                list.Add(new Seat() { Number = count[i] });
            }

            return list;
        }
    }
}
