﻿namespace eFlight.Domain.Test
{
    internal class Sead
    {
    }
}