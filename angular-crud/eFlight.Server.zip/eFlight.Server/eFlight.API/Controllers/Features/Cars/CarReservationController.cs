﻿using eFlight.Application.Features.Cars.Commands;
using eFlight.Application.Features.Cars.Queries;
using eFlight.Domain.Features.Cars;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace eCar.API.Controllers.Features.Cars
{
    [Route("api/[controller]")]
    [ApiController]
    public class CarReservationController : ControllerBase
    {
        private readonly IMediator _mediator;

        public CarReservationController(IMediator mediator)
        {
            _mediator = mediator;
        }

        // GET api/Cars
        [HttpGet]
        public Task<List<CarReservation>> Get()
        {
            return _mediator.Send(new CarReservationLoadAllQuery());
        }

        [HttpPost]
        public async Task<IActionResult> CreateReservation([FromBody] CarReservationRegisterCommand CarRegisterCmd)
        {
            await _mediator.Send(CarRegisterCmd);

            return Ok();
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromBody] CarReservationDeleteCommand CarDeleteCmd)
        {
            var result = await _mediator.Send(CarDeleteCmd);

            if (result) return Ok(); else return BadRequest();
        }

        [HttpPut]
        [Route("{CarId:int}")]
        //TODO: testar Update
        public async Task<IActionResult> Update(int CarId, CarReservationUpdateCommand CarUpdateCmd)
        {
            var result = await _mediator.Send(CarUpdateCmd);

            if (result) return Ok(); else return BadRequest();
        }
    }
}