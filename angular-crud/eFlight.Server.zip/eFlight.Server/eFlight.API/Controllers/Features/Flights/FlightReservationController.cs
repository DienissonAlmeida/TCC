﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using eFlight.Application.Features.Flights.Commands;
using eFlight.Application.Features.Flights.Queries;
using eFlight.Domain.Features.Flights;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace eFlight.API.Controllers.Features.Flights
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightReservationController : ControllerBase
    {
        private readonly IMediator _mediator;

        public FlightReservationController(IMediator mediator)
        {
            _mediator = mediator;
        }

        // GET api/flights
        [HttpGet]
        public Task<List<FlightReservation>> Get()
        {
            return _mediator.Send(new FlightReservationLoadAllQuery());
        }

        [HttpPost]
        public async Task<IActionResult> CreateReservation([FromBody] FlightReservationRegisterCommand flightRegisterCmd)
        {
            var result = await _mediator.Send(flightRegisterCmd);

            if (result) return Ok(); else return BadRequest();
        }

        [HttpDelete]
        public async Task<IActionResult> Delete([FromBody] FlightReservationDeleteCommand flightDeleteCmd)
        {
            var result = await _mediator.Send(flightDeleteCmd);

            if (result) return Ok(); else return BadRequest();
        }

        [HttpPut]
        [Route("{flightId:int}")]
        //TODO: testar Update
        public async Task<IActionResult> Update(int flightId, FlightReservationUpdateCommand flightUpdateCmd)
        {
            var result = await _mediator.Send(flightUpdateCmd);

            if (result) return Ok(); else return BadRequest();
        }
    }
}