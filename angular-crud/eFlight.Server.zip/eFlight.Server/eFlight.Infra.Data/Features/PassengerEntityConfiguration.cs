﻿using eFlight.Domain.Features.Flights;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;
using System;
using System.Collections.Generic;
using System.Text;

namespace eFlight.Infra.Data.Features
{
    class PassengerEntityConfiguration : IEntityTypeConfiguration<Customer>
    {
        public void Configure(EntityTypeBuilder<Customer> builder)
        {
            //builder.HasKey(p => p.Id);
            //builder.Property(p => p.Name);
            //builder.Property(p => p.LastName);
            //builder.Property(p => p.FlightId);
            //builder.Property(p => p.Sex);
        }
    }
}
