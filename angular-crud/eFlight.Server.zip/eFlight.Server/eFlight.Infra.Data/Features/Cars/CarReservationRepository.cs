﻿using eFlight.Data.Context;
using eFlight.Domain.Features.Cars;

namespace eFlight.Infra.Data.Features.Cars
{
    public class CarReservationRepository : RepositoryBase<CarReservation>, ICarReservationRepository
    {
        public CarReservationRepository(eFlightDbContext eFlightDbContext) : base(eFlightDbContext)
        {

        }
    }
}
