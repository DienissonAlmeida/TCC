﻿using System.Collections.Generic;
using System.Threading.Tasks;
using eFlight.Data.Context;
using eFlight.Domain.Features.Hotels;

namespace eFlight.Infra.Data.Features.Hotels
{
    public class HotelReservationRepository : RepositoryBase<HotelReservation>, IHotelReservationRepository
    {
        public HotelReservationRepository(eFlightDbContext eFlightDbContext) : base(eFlightDbContext)
        {

        }
    }
}
